//disable mixins
window.amasty_checkout_disabled = true;