<?php
/**
 * Copyright © Spencer Steiner.
 * See LICENSE.txt for license details.
 */

use \Magento\Framework\Component\ComponentRegistrar;

ComponentRegistrar::register(ComponentRegistrar::MODULE, 'SS_NewsletterAjax', __DIR__);
