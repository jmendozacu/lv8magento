<?php
/**
 * SquareUp
 *
 * Logger Log
 *
 * @category    Squareup
 * @package     Squareup_Omni
 * @copyright   2018
 * @author      SquareUp
 */

namespace Squareup\Omni\Logger;

/**
 * Class Logger
 */
class Logger extends \Monolog\Logger
{

}