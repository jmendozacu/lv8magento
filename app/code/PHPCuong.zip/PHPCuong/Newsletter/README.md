# magento2-ajax-newsletter-subscription
How to use Ajax for the newsletter subscription in Magento 2

# See the video about this tutorial
1. Youtube: https://www.youtube.com/watch?v=6zlSJ6hYgBY&list=PL98CDCbI3TNvPczWSOnpaMoyxVISLVzYQ&index=43
2. Facebook: https://www.facebook.com/giaphugroupcom/videos/2432375640165725/
