var config = {
    map: {
        '*': {
            'Magento_Checkout/js/model/payment-service':'Squareup_Omni/js/model/payment-service'
        }
    }
};
