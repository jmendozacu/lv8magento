<?php
/**
 * Copyright © 2015 Saffron.com. All rights reserved.

 * @author Saffron Team <contact@Saffron.com>
 */

namespace Saffron\Blog\Controller\Adminhtml\Category;

/**
 * Blog category list controller
 */
class Index extends \Saffron\Blog\Controller\Adminhtml\Category
{

}
