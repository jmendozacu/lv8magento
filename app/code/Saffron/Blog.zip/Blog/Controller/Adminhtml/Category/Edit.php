<?php
/**
 * Copyright © 2015 Saffron.com. All rights reserved.

 * @author Saffron Team <contact@Saffron.com>
 */

namespace Saffron\Blog\Controller\Adminhtml\Category;

/**
 * Blog category edit controller
 */
class Edit extends \Saffron\Blog\Controller\Adminhtml\Category
{

}
