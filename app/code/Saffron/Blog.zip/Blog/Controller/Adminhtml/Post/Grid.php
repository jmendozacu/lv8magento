<?php
/**
 * Copyright © 2015 Saffron.com. All rights reserved.

 * @author Saffron Team <contact@Saffron.com>
 */

namespace Saffron\Blog\Controller\Adminhtml\Post;

/**
 * Blog post grid controller
 */
class Grid extends \Saffron\Blog\Controller\Adminhtml\Post
{

}
