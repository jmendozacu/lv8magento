<?php
/**
 * Copyright © 2015 Saffron.com. All rights reserved.

 * @author Saffron Team <contact@Saffron.com>
 */

namespace Saffron\Blog\Controller\Adminhtml\Post;

/**
 * Blog post create new controller
 */
class NewAction extends \Saffron\Blog\Controller\Adminhtml\Post
{

}
