<?php
/**
 * Copyright © 2015 Saffron.com. All rights reserved.

 * @author Saffron Team <contact@Saffron.com>
 */

namespace Saffron\Blog\Controller\Adminhtml\Post;

/**
 * Blog post change status controller
 */
class MassStatus extends \Saffron\Blog\Controller\Adminhtml\Post
{

}
