# ShipStation

Extract the zip file into magento root folder

then execute the setup upgrade command      

php -f bin/magento setup:upgrade    

## Authentication

- Generate an API key in Stores -> Configuration -> Shipstation -> 
Generate and save api key
- In ShipStation, specify the api key
