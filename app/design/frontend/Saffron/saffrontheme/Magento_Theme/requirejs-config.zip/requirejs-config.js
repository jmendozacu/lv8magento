var config = {
    paths: {
        "Aos":  "js/aos"
    }
}